echo "Nicu va saluta! Acum eu o sa instalez tot de ce am nevoie pentru acest script"
echo "Acum eu o sa instalez tot de ce am nevoie pentru acest script"
sleep 5
pkg install git -y
pkg install python -y
pkg install nano -y
echo "IMPORTANT!"
echo "Ca sa va folositi de acest script in failul {config} va scrieti loginul si parola de la gmailul vostru"
echo "Aceasta se poate face cu commanda: nano config"
echo "Mai jos scriti tema mesajului si ce va contine!"
echo "Apoi intrati pe acest sait de pe gmailul care lati ales https://myaccount.google.com/lesssecureapps "
echo "Apoi dam voie la aplicatii putin securizate !"
echo "toate emailurile le scrieti in failul emails_file.txt (1 pe rind)"
echo "dupa asta scrim in terminal: python3 bomb.py"
echo "Info in README.md"


