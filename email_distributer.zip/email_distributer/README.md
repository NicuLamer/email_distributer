#pentu a instala instrumentele
bash setup.sh
#(scrie parola, loginu,tema,mesaju) apoi CTRL+X apoi Y apoi ENTER
nano config
#(pentru a incpe)
python bomber.py

